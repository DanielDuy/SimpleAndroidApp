# Tester for oblig 1

Legg testene inn i "test"-pakken. Det ligger ved et skjermbilde som viser hvilke filer og hvordan de skal ligge når alle delene er ferdig.

Erstatt alle <ditt-brukernavn> i testfilene med ditt brukernavn for å få riktige referanser. Opprett
også en Enum
Class ConverterUnits i "hovedpakken".

```kotlin
enum class ConverterUnits {
    OUNCE,
    CUP,
    GALLON,
    HOGSHEAD
}
```
