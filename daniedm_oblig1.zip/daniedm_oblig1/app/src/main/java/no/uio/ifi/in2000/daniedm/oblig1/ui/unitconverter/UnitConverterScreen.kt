package no.uio.ifi.in2000.daniedm.oblig1.ui.unitconverter

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusEvent
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.navigation.NavHostController
import no.uio.ifi.in2000.daniedm.oblig1.ConverterUnits
import no.uio.ifi.in2000.daniedm.oblig1.converter


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitConverterScreen(navController: NavHostController) {
    var inputNumber by remember { mutableStateOf("") }
    var resultConvertion by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current
    val unitOptions = listOf("OUNCE", "CUP", "GALLON", "HOGSHEAD")
    var isExpanded by remember { mutableStateOf(false) }
    var unitSelected by remember { mutableStateOf(unitOptions[0]) }
    val pattern = remember { Regex("^\\d+\$") }
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column (
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TextField(
                value = inputNumber,
                onValueChange = { if(it.isEmpty() || it.matches(pattern)) {
                    inputNumber = it
                    if (inputNumber.isNotEmpty()) {
                        when (unitSelected) {
                            "OUNCE" -> resultConvertion = converter(inputNumber.toInt(), ConverterUnits.OUNCE).toString()
                            "CUP" -> resultConvertion = converter(inputNumber.toInt(), ConverterUnits.CUP).toString()
                            "GALLON" -> resultConvertion = converter(inputNumber.toInt(), ConverterUnits.GALLON).toString()
                            "HOGSHEAD" -> resultConvertion = converter(inputNumber.toInt(), ConverterUnits.HOGSHEAD).toString()
                        }
                    } else {
                        resultConvertion = "0"
                    }
                } },
                label = { Text("Enter number here:") },
                maxLines = 1,
                modifier = Modifier
                    .focusRequester(focusRequester)
                    .onFocusEvent { focusState ->
                        if (focusState.isFocused) {
                            keyboardController?.show()
                        }
                    },
                keyboardOptions = KeyboardOptions (
                    imeAction = ImeAction.Done,
                    keyboardType = KeyboardType.Number
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        keyboardController?.hide()
                    }
                )
            )
            ExposedDropdownMenuBox(
                expanded = isExpanded,
                onExpandedChange = { isExpanded = !isExpanded}
            ) {
                TextField(
                    modifier = Modifier.menuAnchor(),
                    value = unitSelected,
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExpanded) }
                )
                ExposedDropdownMenu(expanded = isExpanded, onDismissRequest = { isExpanded = false}) {
                    unitOptions.forEachIndexed { index, text ->
                        DropdownMenuItem(
                            text = {Text(text = text)},
                            onClick = {
                                unitSelected = unitOptions[index]
                                isExpanded = false
                                if (inputNumber.isNotEmpty()) {
                                    when (unitSelected) {
                                        "OUNCE" -> resultConvertion = converter(inputNumber.toInt(), ConverterUnits.OUNCE).toString()
                                        "CUP" -> resultConvertion = converter(inputNumber.toInt(), ConverterUnits.CUP).toString()
                                        "GALLON" -> resultConvertion = converter(inputNumber.toInt(), ConverterUnits.GALLON).toString()
                                        "HOGSHEAD" -> resultConvertion = converter(inputNumber.toInt(), ConverterUnits.HOGSHEAD).toString()
                                    }
                                } else {
                                    resultConvertion = "0"
                                }
                            }

                        )
                    }
                }
                Text(text = "Select a unit:")
            }
            TextField(
                value = resultConvertion,
                onValueChange = {},
                maxLines = 1,
                readOnly = true,
                label = { Text("Converted to liter:") }
            )
        }
    }
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomCenter
    ) {
        Button(
            onClick = { navController.navigate("ScreenPalindrome")},
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text(text = "Go to Palindrome Checker")
        }
    }


}

@Preview
@Composable
fun UnitConverterScreenPreview() {
}